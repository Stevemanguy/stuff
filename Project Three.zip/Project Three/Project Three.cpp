// Project Three.cpp 
// Steven Gifford

#include <iostream>
#include <fstream>
#include <map>
#include <string>
#include <algorithm>

class ItemTracker {
private:
    std::map<std::string, int> itemFrequencies;

    // utility function to convert a string to lowercase
    std::string toLower(const std::string& str) {
        std::string lowerStr = str;
        std::transform(lowerStr.begin(), lowerStr.end(), lowerStr.begin(),
            [](unsigned char c) { return std::tolower(c); });
        return lowerStr;
    }

    // utility function to capitalize the first letter and make the rest lowercase
    std::string capitalizeFirstLetter(const std::string& str) {
        if (str.empty()) return "";
        std::string result = toLower(str); // first make the entire string lowercase
        result[0] = std::toupper(result[0]); // then capitalize the first letter
        return result;
    }

    // loads items from the file and counts their frequencies
    void loadItems() {
        std::ifstream inputFile("CS210_Project_Three_Input_File.txt");
        std::string item;
        while (inputFile >> item) {
            item = toLower(item); // normalize the item name to lowercase for internal processing
            ++itemFrequencies[item];
        }
        inputFile.close();
    }

    // backs up the current item frequencies to a file
    void backupData() {
        std::ofstream outputFile("frequency.dat");
        for (const auto& pair : itemFrequencies) {
            outputFile << capitalizeFirstLetter(pair.first) << " " << pair.second << "\n";
        }
        outputFile.close();
    }

public:
    ItemTracker() {
        loadItems(); // load items and their frequencies on construction
        backupData(); // backup data immediately after loading
    }

    // finds and displays the frequency
    void findItemFrequency(const std::string& item) {
        std::string searchItem = toLower(item); // normalize the search query to lowercase
        auto it = itemFrequencies.find(searchItem);
        if (it != itemFrequencies.end()) {
            std::cout << capitalizeFirstLetter(item) << " was purchased " << it->second << " times.\n";
        }
        else {
            std::cout << "Item not found.\n";
        }
    }

    // prints frequencies with names capitalized
    void printAllFrequencies() {
        for (const auto& pair : itemFrequencies) {
            std::cout << capitalizeFirstLetter(pair.first) << " " << pair.second << "\n";
        }
    }

    // prints a histogram of the frequencies with names capitalized
    void printHistogram() {
        for (const auto& pair : itemFrequencies) {
            std::cout << capitalizeFirstLetter(pair.first) << " ";
            for (int i = 0; i < pair.second; ++i) {
                std::cout << "*";
            }
            std::cout << "\n";
        }
    }
};

void displayMenu() {
    std::cout << "1. Find item frequency\n"
        << "2. Print all item frequencies\n"
        << "3. Print histogram of item frequencies\n"
        << "4. Exit\n"
        << "Enter your choice: ";
}

int main() {
    ItemTracker tracker; // create an instance of ItemTracker
    int choice;
    std::string item;

    do {
        displayMenu();
        std::cin >> choice;

        switch (choice) {
        case 1:
            std::cout << "Enter item name: ";
            std::cin >> item;
            tracker.findItemFrequency(item); // search for and display item frequency
            break;
        case 2:
            tracker.printAllFrequencies(); // print frequencies of items
            break;
        case 3:
            tracker.printHistogram(); // print a histogram of frequencies
            break;
        case 4:
            std::cout << "Exiting program.\n";
            break;
        default:
            std::cout << "Invalid choice. Please try again.\n";
        }
    } 
    while (choice != 4);

    return 0;
}
